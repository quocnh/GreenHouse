-- phpMyAdmin SQL Dump
-- version 2.8.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: custsql-ipg66.eigbox.net
-- Generation Time: Dec 10, 2016 at 05:21 AM
-- Server version: 5.6.32
-- PHP Version: 4.4.9
-- 
-- Database: `smartcontroller`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `house`
-- 

CREATE TABLE `house` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `pi_mac_address` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `house`
-- 

INSERT INTO `house` VALUES (1, 'Raspberry1', 'B8-27-EB-DC-C0-65', 7);
INSERT INTO `house` VALUES (2, 'Raspberry2', '', 7);
INSERT INTO `house` VALUES (3, 'Raspberry3', '', 8);

-- --------------------------------------------------------

-- 
-- Table structure for table `login`
-- 

CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('Member','Administrator') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Member',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `login`
-- 

INSERT INTO `login` VALUES (6, 'admin', '21232f297a57a5a743894a0e4a801fc3', '', '', 'Administrator');
INSERT INTO `login` VALUES (7, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'Phu Yen', 'Trai Nam Phu Yen. Mr Quoc', 'Member');
INSERT INTO `login` VALUES (8, 'mark', 'ea82410c7a9991816b5eeeebe195e20a', 'Nha Trang', 'Trai Nam Nha Trang. Mr Dung', 'Member');

-- 
-- Constraints for dumped tables
-- 

-- 
-- Constraints for table `house`
-- 
ALTER TABLE `house`
  ADD CONSTRAINT `house_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `login` (`id`);
